function leer_datos(){
  $.ajax(
  'php/leer_datos.php',
  {
      success: function(data) {

      $('#mostrarDatos').html(data);
        console.log(data);
      },
      error: function() {
        console.log();('There was some error performing the AJAX call!');
      }
   });

}
