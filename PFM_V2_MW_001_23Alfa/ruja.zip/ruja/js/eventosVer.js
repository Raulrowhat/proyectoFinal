$( document ).ready(function() {
    leer_datos();
});

$('li').click(function () {
  $('li').removeClass('selected');
  $(this).toggleClass('selected');
  console.log($(this)[0].id);
  console.log($(this)[0]);
  console.log($(this));
/*  if ($('li.selected').length == 0)
    $('.select').removeClass('selected');
  else
    $('.select').addClass('selected');
  counter();*/
});
/*
// all item selection
$('.select').click(function () {
  if ($('li.selected').length == 0) {
    $('li').addClass('selected');
    $('.select').addClass('selected');
  }
  else {
    $('li').removeClass('selected');
    $('.select').removeClass('selected');
  }
  counter();
});
*/
