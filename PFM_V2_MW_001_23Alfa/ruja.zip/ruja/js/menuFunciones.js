// number of selected items
function counter() {
  if ($('li.selected').length > 0)
    $('#botonGuardar').addClass('selected');
  else
    $('#botonGuardar').removeClass('selected');
}

function leerDatos(){
  $.ajax(
  'php/leer_datos.php',
  {
      success: function(data) {
        $('#contenedorVerDatos').html(data);
      },
      error: function() {
          $('#contenedorVerDatos').html("Error en ajax");
      }
   });
}

function leerDatosDavid(){
  $.ajax(
  'php/leer_datos2.php',
  {
      success: function(data) {
        $('#contenedorVerDatos').html(data);
      },
      error: function() {
          $('#contenedorVerDatos').html("Error en ajax");
      }
   });
}


function guardarDatos(){
  $.ajax(
  'php/guardar_datos.php',
  {
      method:'POST',
      data:{
          valor:idGuardar
      },
      success: function(data) {
        console.log();('AJAX call was successful!');
        console.log(data);
      },
      error: function() {
        console.log();('There was some error performing the AJAX call!');
      }
   });
  idGuardar = "";
}


function borrarDatos(){
  $.ajax(
  'php/borrar_datos.php',
  {
      success: function(data) {
        console.log();('AJAX call was successful!');
        console.log(data);
      },
      error: function() {
        console.log();('There was some error performing the AJAX call!');
      }
   });
}
