$( document ).ready(function() {
  $('#contenedorMenu').show();
});

$('li').click(function () {
  $('li').removeClass('selected');
  $(this).toggleClass('selected');
  idGuardar = $(this)[0].id;
  console.log(idGuardar);
  counter();

});

$('#botonGuardar').click(function () {
    guardarDatos();
    $('#botonGuardar').removeClass('selected');
    $('li').removeClass('selected');

});

$('.menu').mousedown(function () {
  $(this).removeClass('selected');
});

$('.menu').mouseup(function () {
  $(this).addClass('selected');
  switch ($(this)[0].id) {
    case "encuesta":
      $('#contenedorMenu').hide();
      $('#contenedorEncuesta').show();
      break;
    case "verDatos":
      leerDatos();
      $('#contenedorMenu').hide();
      $('#contenedorVerDatos').show();
      break;
    case "verDatosDavid":
        leerDatosDavid();
        $('#contenedorMenu').hide();
        $('#contenedorVerDatos').show();
        break;

    case "borrarDatos":
      borrarDatos();
      break;

    default:

  }
});
