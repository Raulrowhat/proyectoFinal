// number of selected items
function counter() {
  if ($('li.selected').length > 0)
    $('.send').addClass('selected');
  else
    $('.send').removeClass('selected');
  //$('.send').attr('data-counter',$('li.selected').length);
}

function leer_datos(){
  console.log("leyendo");
/*  $.ajax({
    type: "GET",
    url: 'php/leer_datos.php',
    async: false,
    dataType: "json",
    success: function(data){console.log(data);},
    error: function(data) {console.log('error');}
  });*/

  $.ajax(
  'php/leer_datos.php',
  {

      success: function(data) {
        console.log();('AJAX call was successful!');
        console.log(data);
      },
      error: function() {
        console.log();('There was some error performing the AJAX call!');
      }
   });

}


function guardarDatos(){
  console.log(idGuardar);

  $.ajax(
  'php/guardar_datos.php',
  {
      method:'POST',
      data:{
          valor:idGuardar
      },
      success: function(data) {
        console.log();('AJAX call was successful!');
        console.log(data);
      },
      error: function() {
        console.log();('There was some error performing the AJAX call!');
      }
   });
  idGuardar = "";
}
