$( document ).ready(function() {
    leer_datos();
});

$('li').click(function () {
  $('li').removeClass('selected');
  $(this).toggleClass('selected');
  idGuardar = $(this)[0].id;
  console.log(idGuardar);
  counter();
/*  if ($('li.selected').length == 0)
    $('.select').removeClass('selected');
  else
    $('.select').addClass('selected');
  counter();*/
});
/*
// all item selection
$('.select').click(function () {
  if ($('li.selected').length == 0) {
    $('li').addClass('selected');
    $('.select').addClass('selected');
  }
  else {
    $('li').removeClass('selected');
    $('.select').removeClass('selected');
  }
  counter();
});
*/

$('.send').click(function () {
    guardarDatos();
    $('.send').removeClass('selected');
    $('li').removeClass('selected');

});
