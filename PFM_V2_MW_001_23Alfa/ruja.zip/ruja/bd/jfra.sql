-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-02-2020 a las 08:14:30
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `jfra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruja`
--

CREATE TABLE `ruja` (
  `ID_REG` int(11) NOT NULL,
  `FH_REG` datetime NOT NULL DEFAULT current_timestamp(),
  `VALOR` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ruja`
--

INSERT INTO `ruja` (`ID_REG`, `FH_REG`, `VALOR`) VALUES
(30, '2020-02-14 18:09:16', 'ElDeporte'),
(31, '2020-02-14 18:09:18', 'IrAlCine'),
(32, '2020-02-14 18:09:21', 'IrDeTiendas'),
(33, '2020-02-14 18:09:29', 'IrDeTiendas'),
(34, '2020-02-14 18:17:22', 'IrAlCine'),
(35, '2020-02-14 18:17:24', 'IrDeTiendas'),
(36, '2020-02-14 18:17:27', 'IrAlCine'),
(37, '2020-02-14 18:17:29', 'IrAlCine'),
(38, '2020-02-14 18:38:53', 'IrDeTiendas'),
(39, '2020-02-14 18:38:55', 'IrAlCine'),
(40, '2020-02-14 18:38:58', 'ElDeporte');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ruja`
--
ALTER TABLE `ruja`
  ADD PRIMARY KEY (`ID_REG`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ruja`
--
ALTER TABLE `ruja`
  MODIFY `ID_REG` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
