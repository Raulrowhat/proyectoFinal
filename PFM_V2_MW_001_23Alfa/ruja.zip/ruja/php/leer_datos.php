<?php


include 'vars.php';



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT distinct valor AS VALOR, count(valor) AS CANTIDAD FROM ruja
        GROUP BY VALOR ORDER BY VALOR";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["VALOR"]. " - " . $row["CANTIDAD"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();

/*
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "jfra";


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "epiz_25195168_jfra";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT distinct valor AS VALOR, count(valor) AS CANTIDAD FROM ruja
        GROUP BY VALOR ORDER BY VALOR";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["VALOR"]. " - " . $row["CANTIDAD"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
*/
?>
