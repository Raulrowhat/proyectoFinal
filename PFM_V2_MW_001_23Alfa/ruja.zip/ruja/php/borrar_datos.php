<?php


include 'vars.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "DELETE FROM ruja";

if ($conn->query($sql) === TRUE) {
    echo "datos borrados";
}
else
{
    echo "failed";
}
?>
