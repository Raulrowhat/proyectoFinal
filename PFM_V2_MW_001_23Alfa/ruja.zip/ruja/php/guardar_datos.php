<?php


include 'vars.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$valor=$_POST['valor'];

$sql="INSERT INTO ruja (valor) VALUES ('$valor')";

if ($conn->query($sql) === TRUE) {
    echo "data inserted";
}
else
{
    echo "failed";
}
?>
