<?php

$servername = "sql203.epizy.com";
$username = "epiz_25195168";
$password = "2VCRUmGOEO";
$dbname = "epiz_25195168_jfra";

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "jfra";

?>
